//
//  Cat.m
//  VariousForm
//
//  Created by bo on 16/8/26.
//  Copyright © 2016年 jike. All rights reserved.
//

#import "Cat.h"

@implementation Cat

-(void)eat {
    NSLog(@"喵星人吃东西!");
}

@end
