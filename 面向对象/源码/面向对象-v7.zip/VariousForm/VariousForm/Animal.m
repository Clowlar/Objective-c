//
//  Animal.m
//  VariousForm
//
//  Created by bo on 16/8/26.
//  Copyright © 2016年 jike. All rights reserved.
//

#import "Animal.h"

@implementation Animal

-(void)eat {
    NSLog(@"动物吃东西!");
}

@end
