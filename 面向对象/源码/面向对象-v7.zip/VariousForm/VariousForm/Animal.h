//
//  Animal.h
//  VariousForm
//
//  Created by bo on 16/8/26.
//  Copyright © 2016年 jike. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Animal : NSObject

-(void)eat;

@end
