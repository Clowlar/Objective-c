//
//  Dog.m
//  VariousForm
//
//  Created by bo on 16/8/26.
//  Copyright © 2016年 jike. All rights reserved.
//

#import "Dog.h"

@implementation Dog

-(void)eat {
    NSLog(@"汪星人吃东西!");
}

-(void)run {
    NSLog(@"汪星人跑步");
}

@end
