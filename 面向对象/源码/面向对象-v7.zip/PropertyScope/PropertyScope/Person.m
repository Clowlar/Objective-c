//
//  Person.m
//  PropertyScope
//
//  Created by bo on 16/8/29.
//  Copyright © 2016年 jike. All rights reserved.
//

#import "Person.h"

//给变量增加const属性，表示外界就不能修改它的值了
const NSString *str = @"天气不错"; //外部变量，可以被任何类访问
@implementation Person

@end
